/**
 * service-worker.js - Service Worker for LazyOMR web app.
 * Caches the app shell and OpenCV.js for offline use.
 *
 * (c) 2026 Dilshan-H (https://github.com/Dilshan-H)
 * Licensed under MIT
 */
const CACHE_NAME = "lazyomr-cache-v1.1.0";
const OPENCV_URL = "https://docs.opencv.org/4.9.0/opencv.js";

const APP_SHELL = [
  "index.html",
  "css/theme.css",
  "css/app.css",
  "js/app.js",
  "js/layout.js",
  "js/storage.js",
  "js/exam.js",
  "js/scan.js",
  "manifest.webmanifest",
  "icons/icon-192.png",
  "icons/icon-512.png",
  "icons/icon-maskable-192.png",
  "icons/icon-maskable-512.png",
  "screenshots/screenshot-n-1.jpg",
  "screenshots/screenshot-n-2.jpg",
  "screenshots/screenshot-n-3.jpg",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      await cache.addAll(APP_SHELL);
      try {
        const res = await fetch(OPENCV_URL, { mode: "no-cors" });
        await cache.put(OPENCV_URL, res);
      } catch (e) {
        // No connectivity yet - will cache next time
      }
      self.skipWaiting();
    })(),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)),
      );
      await self.clients.claim();
    })(),
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  event.respondWith(
    (async () => {
      const cached = await caches.match(req, { ignoreSearch: true });
      if (cached) return cached;

      try {
        const res = await fetch(req);
        const isOpenCv = req.url === OPENCV_URL;
        const sameOrigin = req.url.startsWith(self.location.origin);
        if ((sameOrigin && res.ok) || isOpenCv) {
          const cache = await caches.open(CACHE_NAME);
          cache.put(req, res.clone());
        }
        return res;
      } catch (e) {
        return cached || Response.error();
      }
    })(),
  );
});
