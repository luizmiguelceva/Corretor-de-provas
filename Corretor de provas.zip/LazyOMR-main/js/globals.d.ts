/**
 * AppStorage - A namespace for managing LazyOMR application data in localStorage.
 * Provides methods to get, save, update, and delete settings, exams, and results.
 */
declare const AppStorage: {
  /**
   * Retrieves the current LazyOMR settings from localStorage.
   * @returns {Settings} The current settings.
   */
  getSettings: () => Settings;

  /**
   * Saves the LazyOMR settings to localStorage.
   * @param {Partial<Settings>} patch - The settings to update.
   * @returns {Settings} The updated settings.
   */
  saveSettings: (patch: Partial<Settings>) => Settings;

  /**
   * Retrieves the list of all exams from localStorage.
   * @returns {Array<Exam> | null} The list of exams.
   */
  getExams: () => Exam[];

  /**
   * Saves the list of all exams to localStorage.
   * @param {Array<Exam>} exams - The list of exams to save.
   */
  saveExams: (exams: Exam[]) => void;

  /**
   * Retrieves an exam by its ID from localStorage.
   * @param {string} id - The ID of the exam to retrieve.
   * @returns {Exam | null} The exam if found, otherwise null.
   */
  getExam: (examId: string) => Exam | null;

  /**
   * Creates a new exam.
   * @param {Object} options - The options for the new exam.
   * @param {string} options.title - The title of the exam.
   * @param {string} options.date - The date of the exam.
   * @param {number} options.numQuestions - The number of questions in the exam.
   * @param {Array<string>} options.answerKey - The answer key for the exam.
   * @param {"full"|"compact"} [options.sheetFormat] - Sheet format: "full" (1 per A4 page) or "compact" (up to 4 per A4 page).
   * @returns {Exam} The created exam.
   */
  createExam: (options: {
    title: string;
    date: string;
    numQuestions: number;
    answerKey: string[];
    sheetFormat?: "full" | "compact";
  }) => Exam;

  /**
   * Updates an existing exam.
   * @param {string} id - The ID of the exam to update.
   * @param {Partial<Exam>} patch - The changes to apply to the exam.
   * @returns {Exam | null} The updated exam if found, otherwise null.
   */
  updateExam: (examId: string, patch: Partial<Exam>) => Exam | null;

  /**
   * Deletes an exam from localStorage.
   * @param {string} id - The ID of the exam to delete.
   */
  deleteExam: (examId: string) => void;

  /**
   * Adds a result to an exam.
   * @param {string} examId - The ID of the exam to add the result to.
   * @param {Object} result - The result to add.
   * @returns {number | null} Returns the index of the added result
   */
  addResultToExam: (examId: string, result: Result[]) => number | null;

  /**
   * Deletes a result from an exam.
   * @param {string} examId - The ID of the exam to delete the result from.
   * @param {string} resultId - The ID of the result to delete.
   * @returns {Exam | null} The updated exam if found, otherwise null.
   */
  deleteResultFromExam: (examId: string, resultId: string) => Exam | null;

  /**
   * Clears all LazyOMR data from localStorage.
   */
  clearAllData: () => void;
};

//==========================

/**
 * LayoutUtils - A namespace for layout-related utility functions and constants.
 * Provides methods to convert between millimeters and pixels, and defines the layout of the OMR sheet.
 */
declare const LayoutUtils: {
  /**
   * Geometry of each sheet format, in millimeters.
   * "full": one sheet per A4 page (2 columns x 25 rows, options A-E).
   * "compact": up to four sheets per A4 page (3 columns x 17 rows, options A-E).
   */
  LAYOUTS: Record<"full" | "compact", SheetLayout>;

  /** The original single-sheet layout (same as LAYOUTS.full). */
  LAYOUT_MM: SheetLayout;

  /** Option labels used on every sheet: A, B, C, D, E. */
  OPTION_LABELS: string[];

  /** How many compact sheets fit on a single A4 page. */
  COMPACT_SHEETS_PER_PAGE: number;

  /** @constant {number} PX_PER_MM of the "full" format (the compact format uses its own value). */
  readonly PX_PER_MM: number;

  /** Returns the layout for a sheet format ("full" when unknown). */
  getLayout: (mode?: string) => SheetLayout;

  /** Converts a stored exam sheet format into "full" | "compact" (old exams -> "full"). */
  normalizeMode: (format?: string) => "full" | "compact";

  /** Top-left origin (mm, on the A4 page) of each of the 4 compact sheet slots. */
  getCompactSlots: () => Array<{ x: number; y: number }>;

  /** Pixels per millimeter used in the canonical (post-dewarp) space of a format. */
  pxPerMm: (mode?: string) => number;

  /** Converts millimeters to canonical pixels for a sheet format. */
  mmToPx: (mm: number, mode?: string) => number;

  /**
   * Returns the 4 marker centers in canonical pixel space, in the
   * fixed order [topLeft, topRight, bottomRight, bottomLeft].
   */
  getCanonicalMarkerCenters: (mode?: string) => Array<{ x: number; y: number }>;

  /** Returns the size of the canonical pixel space for a sheet format. */
  getCanonicalSize: (mode?: string) => { width: number; height: number };

  /** Bubble centers in millimeters, one entry per (question, option). */
  getBubbleGrid: (mode?: string) => Array<{
    question: number;
    option: string;
    xMm: number;
    yMm: number;
  }>;

  /** Bubble centers in canonical pixels, one entry per (question, option). */
  getBubbleGridPx: (mode?: string) => Array<{
    question: number;
    option: string;
    x: number;
    y: number;
  }>;
};

interface SheetLayout {
  page: { width: number; height: number };
  marker: { size: number; inset: number };
  header: { top: number; height: number; margin: number };
  noteBox: { top: number; margin: number };
  studentInfo: { top: number; height: number; margin: number };
  pxPerMm: number;
  grid: {
    top: number;
    bottom: number;
    numQuestions: number;
    columns: number;
    optionsPerQuestion: number;
    optionLabels: string[];
    sideMargin: number;
    colGap: number;
    rowHeight: number;
    bubbleDiameter: number;
    bubbleGap: number;
    questionLabelWidth: number;
  };
}
