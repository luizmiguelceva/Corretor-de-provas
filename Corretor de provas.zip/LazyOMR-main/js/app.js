/**
 * app.js - Main JavaScript for LazyOMR web app
 * Init route handling, theme, splash screen, bottom sheet, toast, PWA install & service worker
 *
 * (c) 2026 Dilshan-H (https://github.com/Dilshan-H)
 * Licensed under MIT
 */

// ---------------- Theme ----------------
const THEME_KEY = "lazyomr_theme"; // 'light' | 'dark'

/**
 * Applies the specified theme to the application.
 * @param {'light' | 'dark'} choice - The theme to apply.
 */
function applyTheme(choice) {
  const root = document.documentElement;
  if (choice === "dark") root.setAttribute("data-theme", "dark");
  else root.setAttribute("data-theme", "light");
  document.querySelectorAll("#themeToggle button").forEach((b) => {
    b.classList.toggle("active", b.dataset.themeChoice === choice);
  });
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta)
    meta.setAttribute(
      "content",
      getComputedStyle(root).getPropertyValue("--bg").trim(),
    );
}

/**
 * Initializes the theme based on saved preference or system preference.
 */
function initTheme() {
  const saved = localStorage.getItem(THEME_KEY);
  const systemPrefersDark = window.matchMedia(
    "(prefers-color-scheme: dark)",
  ).matches;
  applyTheme(saved || (systemPrefersDark ? "dark" : "light"));
}

document.getElementById("themeToggle").addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-theme-choice]");
  if (!btn) return;
  const choice = btn.dataset.themeChoice;
  localStorage.setItem(THEME_KEY, choice);
  applyTheme(choice);
});

// ---------------- Splash ----------------
window.addEventListener("load", () => {
  const MIN_SPLASH_MS = 900;
  setTimeout(() => {
    document.getElementById("splash").classList.add("hide");
  }, MIN_SPLASH_MS);
});

// ---------------- Router (hash-based) ----------------
const SCREENS = ["home", "new-exam", "scan", "history", "settings"];

/**
 * Extracts the current route from the URL hash.
 * @returns {Object} The current route object with 'name' and 'param' properties.
 */
function currentRouteFromHash() {
  const raw = (location.hash || "#home").replace("#", "");
  const [name, param] = raw.split(":");
  return { name: SCREENS.includes(name) ? name : "home", param: param || null };
}

/**
 * Displays the specified screen.
 * @param {string} name - The name of the screen to display.
 * @param {string|null} param - The parameter for the screen.
 */
function showScreen(name, param) {
  SCREENS.forEach((s) => {
    document
      .getElementById("screen-" + s)
      .classList.toggle("active", s === name);
  });
  window.scrollTo(0, 0);
  document.dispatchEvent(
    new CustomEvent("screenshow", { detail: { name, param } }),
  );
}

/**
 * Navigates to the specified screen.
 * @param {string} name - The name of the screen to navigate to.
 */
function navigateTo(name) {
  if (location.hash.replace("#", "") === name) {
    showScreen(...currentRouteAsArgs());
    return;
  }
  location.hash = name;
}

/**
 * Returns the current route as an array of arguments for showScreen.
 * @returns {Array} An array containing the screen name and parameter.
 */
function currentRouteAsArgs() {
  const r = currentRouteFromHash();
  return [r.name, r.param];
}

window.addEventListener("hashchange", () =>
  showScreen(...currentRouteAsArgs()),
);

document.querySelectorAll("[data-nav]").forEach((el) => {
  el.addEventListener("click", () => navigateTo(el.dataset.nav));
});
document.querySelectorAll("[data-back]").forEach((el) => {
  el.addEventListener("click", () => navigateTo("home"));
});

/**
 * Navigates to the specified screen with a parameter.
 * @param {string} name - The name of the screen to navigate to.
 * @param {string|null} param - The parameter for the screen.
 */
function navigateToWithParam(name, param) {
  location.hash = param ? `${name}:${param}` : name;
}
window.navigateTo = navigateTo;
window.navigateToWithParam = navigateToWithParam;

// ---------------- Bottom sheet swipe-to-close gesture ----------------
let sheetSwipeStart = null;
const SHEET_SWIPE_THRESHOLD = 100; // px

/**
 * Sets up the swipe-to-close gesture for a bottom sheet.
 * @param {string} sheetId - The ID of the sheet element.
 * @param {string} overlayId - The ID of the overlay element.
 * @param {Function} closeCallback - The function to call when the sheet is closed.
 */
function setupSheetSwipeGesture(sheetId, overlayId, closeCallback) {
  const sheet = document.getElementById(sheetId);

  sheet.addEventListener("touchstart", (e) => {
    sheetSwipeStart = { y: e.touches[0].clientY };
  });

  sheet.addEventListener("touchmove", (e) => {
    if (!sheetSwipeStart) return;
    // Only allow swipe when scrolled to top to avoid interfering with scrolling
    if (sheet.scrollTop > 0) {
      sheetSwipeStart = null;
      return;
    }

    const delta = e.touches[0].clientY - sheetSwipeStart.y;

    if (delta > 0 && sheet.scrollTop === 0) {
      if (sheet.style.transition !== "none") {
        sheet.style.transition = "none";
      }
      sheet.style.transform = `translateY(${delta * 0.4}px)`;
    }
  });

  sheet.addEventListener("touchend", (e) => {
    if (!sheetSwipeStart) return;
    const endY = e.changedTouches[0].clientY;
    const delta = endY - sheetSwipeStart.y;

    sheet.style.transition = "";
    sheet.style.transform = "";

    // Downward swipe (positive delta) beyond threshold closes the sheet
    if (delta > SHEET_SWIPE_THRESHOLD) {
      closeCallback();
    }
    sheetSwipeStart = null;
  });
}

// ---------------------- Bottom sheet - [About] ----------------------
const aboutOverlay = document.getElementById("aboutOverlay");
const aboutSheet = document.getElementById("aboutSheet");

function openAbout() {
  aboutOverlay.classList.add("open");
  aboutSheet.classList.add("open");
}
function closeAbout() {
  aboutOverlay.classList.remove("open");
  aboutSheet.classList.remove("open");
}
document.getElementById("creditBar").addEventListener("click", openAbout);
aboutOverlay.addEventListener("click", closeAbout);

// Setup swipe-to-close gesture for about sheet
setupSheetSwipeGesture("aboutSheet", "aboutOverlay", closeAbout);

document.querySelectorAll(".pill-item .pill-head").forEach((head) => {
  head.addEventListener("click", () => {
    const item = head.closest(".pill-item");
    const body = item.querySelector(".pill-body");
    const isOpen = item.classList.contains("open");
    // accordion: close any other open pill first
    document.querySelectorAll(".pill-item.open").forEach((openItem) => {
      if (openItem !== item) {
        openItem.classList.remove("open");
        openItem.querySelector(".pill-body").style.maxHeight = null;
      }
    });
    item.classList.toggle("open", !isOpen);
    body.style.maxHeight = !isOpen ? body.scrollHeight + "px" : null;
  });
});

// ---------------- Toast Notifications ----------------

/**
 * Displays a toast notification.
 * @param {string} message - The message to display.
 * @param {number} ms - The duration to display the toast (in milliseconds).
 */
function toast(message, ms = 2400) {
  const host = document.getElementById("toastHost");
  const el = document.createElement("div");
  el.className = "toast";
  el.textContent = message;
  host.appendChild(el);
  requestAnimationFrame(() => el.classList.add("show"));
  setTimeout(() => {
    el.classList.remove("show");
    setTimeout(() => el.remove(), 300);
  }, ms);
}
window.toast = toast;

// ---------------- Service Worker ----------------
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("service-worker.js").catch(() => {
      // offline-on-first-load or unsupported host — app still works online
    });
  });
}

// ---------------- PWA install button ----------------
let deferredInstallPrompt = null;
const installBtn = document.getElementById("installBtn");
const isIOS = /iphone|ipad|ipod/.test(navigator.userAgent.toLowerCase());

/**
 * Checks if the app is running in standalone mode.
 * @returns {boolean} True if the app is running in standalone mode, false otherwise.
 */
function isStandaloneMode() {
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    window.navigator.standalone === true
  );
}

/**
 * Updates the visibility of the PWA install button based on the mode.
 * @returns {void}
 */
function updateInstallButtonVisibility() {
  if (isStandaloneMode()) {
    installBtn.style.display = "none";
    return;
  }
  installBtn.style.display = deferredInstallPrompt || isIOS ? "" : "none";
}

window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;
  updateInstallButtonVisibility();
});
window.addEventListener("appinstalled", () => {
  deferredInstallPrompt = null;
  updateInstallButtonVisibility();
  toast("Installed — find it on your home screen");
});
installBtn.addEventListener("click", async () => {
  if (deferredInstallPrompt) {
    deferredInstallPrompt.prompt();
    await deferredInstallPrompt.userChoice;
    deferredInstallPrompt = null;
    updateInstallButtonVisibility();
  } else if (isIOS) {
    toast('Tap the Share icon, then "Add to Home Screen"', 4000);
  }
});
updateInstallButtonVisibility();

// ---------------- Init ----------------
initTheme();
showScreen(...currentRouteAsArgs());
