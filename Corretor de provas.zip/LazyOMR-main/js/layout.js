/**
 * layout.js - Defines the layout of the OMR sheet in millimeters.
 * and provides utility functions to be used by exam.js and scan.js
 *
 * Two sheet formats are supported:
 *  - "full":    one sheet per A4 page. 50 questions max, 2 columns of 25 rows,
 *               5 options (A/B/C/D/E) per question.
 *  - "compact": up to four sheets per A4 page (2 x 2, cut the page afterwards).
 *               Each sheet is 100 x 143.5 mm with its own 4 corner markers.
 *               50 questions max, 3 columns of 17 rows, 5 options (A-E) per question.
 *
 * All helper functions take an optional `mode` ("full" | "compact"), default "full".
 *
 * (c) 2026 Dilshan-H (https://github.com/Dilshan-H)
 * Licensed under MIT
 */

const OPTION_LABELS = ["A", "B", "C", "D", "E"];

// Margin (mm) kept free around the A4 page when several sheets are tiled on it,
// since most printers cannot print right up to the paper edge.
const COMPACT_PAGE_MARGIN = 5;
const A4_MM = { width: 210, height: 297 };

const LAYOUTS = {
  full: {
    page: { width: 210, height: 297 }, // A4

    // Solid square markers, one per corner
    marker: {
      size: 12, // mm, edge length of each square
      inset: 8, // mm, distance from page edge to the marker's outer edge
    },

    // Institution name, exam title, date
    header: {
      top: 14,
      height: 26,
      margin: 15, // mm, left/right margin of the header
    },

    // Instructional text
    noteBox: {
      top: 32,
      margin: 15,
    },

    // Student info fields [name, id]
    studentInfo: {
      top: 44,
      height: 16,
      margin: 15,
    },

    // px-per-mm used for all canonical (post de-warp) pixel calculations.
    pxPerMm: 4,

    // Bubble grid
    grid: {
      top: 70,
      bottom: 20, // mm reserved at bottom below the grid
      numQuestions: 50,
      columns: 2,
      optionsPerQuestion: OPTION_LABELS.length,
      optionLabels: OPTION_LABELS,
      sideMargin: 15, // mm, left/right page margin of the grid
      colGap: 10, // mm gap between the column blocks
      rowHeight: 7.6, // mm per question row
      bubbleDiameter: 4.2,
      bubbleGap: 8.2, // mm, center-to-center spacing between option bubbles
      questionLabelWidth: 10, // mm reserved for the label before bubbles ("1.", "2.")
    },
  },

  compact: {
    // One of the four sheets that share an A4 page
    page: {
      width: (A4_MM.width - 2 * COMPACT_PAGE_MARGIN) / 2, // 100
      height: (A4_MM.height - 2 * COMPACT_PAGE_MARGIN) / 2, // 143.5
    },

    marker: {
      size: 7,
      inset: 3,
    },

    header: {
      top: 4,
      height: 11,
      margin: 13, // keeps the header between the two top markers
    },

    noteBox: {
      top: 15,
      margin: 6,
    },

    studentInfo: {
      top: 24,
      height: 9,
      margin: 6,
    },

    // Higher resolution because each bubble is physically smaller.
    pxPerMm: 6,

    grid: {
      top: 40,
      bottom: 10,
      numQuestions: 50,
      columns: 3,
      optionsPerQuestion: OPTION_LABELS.length,
      optionLabels: OPTION_LABELS,
      sideMargin: 6,
      colGap: 2.5,
      rowHeight: 5.2,
      bubbleDiameter: 3.6,
      bubbleGap: 4.9,
      questionLabelWidth: 6,
    },
  },
};

// Kept for backwards compatibility (the original single-sheet layout)
const LAYOUT_MM = LAYOUTS.full;

// Number of compact sheets that fit on one A4 page
const COMPACT_SHEETS_PER_PAGE = 4;

/**
 * Returns the layout object for a sheet format.
 * @param {"full"|"compact"} [mode]
 */
function getLayout(mode = "full") {
  return LAYOUTS[mode] || LAYOUTS.full;
}

/**
 * Normalises whatever is stored on an exam into a valid sheet format.
 * Exams saved before the compact format existed have no format -> "full".
 * @param {string} [format]
 * @returns {"full"|"compact"}
 */
function normalizeMode(format) {
  return format === "compact" ? "compact" : "full";
}

/**
 * Returns the top-left origin (mm, on the A4 page) of each compact sheet slot,
 * in reading order: top-left, top-right, bottom-left, bottom-right.
 * @returns {Array<{x: number, y: number}>}
 */
function getCompactSlots() {
  const { page } = LAYOUTS.compact;
  const slots = [];
  for (let i = 0; i < COMPACT_SHEETS_PER_PAGE; i++) {
    slots.push({
      x: COMPACT_PAGE_MARGIN + (i % 2) * page.width,
      y: COMPACT_PAGE_MARGIN + Math.floor(i / 2) * page.height,
    });
  }
  return slots;
}

function pxPerMm(mode = "full") {
  return getLayout(mode).pxPerMm;
}

function mmToPx(mm, mode = "full") {
  return Math.round(mm * pxPerMm(mode));
}

function getCanonicalMarkerCenters(mode = "full") {
  const { page, marker } = getLayout(mode);
  const half = marker.size / 2;
  const left = marker.inset + half;
  const right = page.width - marker.inset - half;
  const top = marker.inset + half;
  const bottom = page.height - marker.inset - half;
  return [
    { x: mmToPx(left, mode), y: mmToPx(top, mode) }, // top-left
    { x: mmToPx(right, mode), y: mmToPx(top, mode) }, // top-right
    { x: mmToPx(right, mode), y: mmToPx(bottom, mode) }, // bottom-right
    { x: mmToPx(left, mode), y: mmToPx(bottom, mode) }, // bottom-left
  ];
}

function getCanonicalSize(mode = "full") {
  const { page } = getLayout(mode);
  return {
    width: mmToPx(page.width, mode),
    height: mmToPx(page.height, mode),
  };
}

function getBubbleGrid(mode = "full") {
  const g = getLayout(mode).grid;
  const page = getLayout(mode).page;
  const rowsPerCol = Math.ceil(g.numQuestions / g.columns);
  const colWidth =
    (page.width - 2 * g.sideMargin - (g.columns - 1) * g.colGap) / g.columns;

  const bubbles = []; // { question, option, xMm, yMm }
  for (let q = 1; q <= g.numQuestions; q++) {
    const col = Math.floor((q - 1) / rowsPerCol);
    const rowInCol = (q - 1) % rowsPerCol;
    const colLeft = g.sideMargin + col * (colWidth + g.colGap);
    const yMm = g.top + rowInCol * g.rowHeight;
    for (let o = 0; o < g.optionsPerQuestion; o++) {
      const xMm = colLeft + g.questionLabelWidth + o * g.bubbleGap;
      bubbles.push({ question: q, option: g.optionLabels[o], xMm, yMm });
    }
  }
  return bubbles;
}

function getBubbleGridPx(mode = "full") {
  return getBubbleGrid(mode).map((b) => ({
    question: b.question,
    option: b.option,
    x: mmToPx(b.xMm, mode),
    y: mmToPx(b.yMm, mode),
  }));
}

window.LayoutUtils = {
  LAYOUTS,
  LAYOUT_MM,
  OPTION_LABELS,
  COMPACT_SHEETS_PER_PAGE,
  PX_PER_MM: LAYOUTS.full.pxPerMm,
  getLayout,
  normalizeMode,
  getCompactSlots,
  pxPerMm,
  mmToPx,
  getCanonicalMarkerCenters,
  getCanonicalSize,
  getBubbleGrid,
  getBubbleGridPx,
};
