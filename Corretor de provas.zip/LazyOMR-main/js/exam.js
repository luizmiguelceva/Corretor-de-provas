/**
 * exam.js - Handler for the exam-related screens in LazyOMR web app
 * Handles the new exam wizard, history list, settings screen & print preview.
 * Init route handling, theme, splash screen, bottom sheet, toast, PWA install & service worker
 * Utilizes 'storage.js' assigned namespace [AppStorage] to read/write localStorage.
 *
 * (c) 2026 Dilshan-H (https://github.com/Dilshan-H)
 * Licensed under MIT
 */

// ================= NEW EXAM WIZARD =================
let wizard = {
  step: 1,
  title: "",
  date: "",
  numQuestions: 50,
  sheetFormat: "compact",
  answerKey: {},
};

/**
 * Resets the new exam wizard to its initial state.
 * And call goToWizardStep(1) to show the first step of the wizard.
 */
function resetWizard() {
  const today = new Date().toISOString().slice(0, 10);
  wizard = {
    step: 1,
    title: "",
    date: today,
    numQuestions: 50,
    sheetFormat: "compact",
    answerKey: {},
  };
  document.getElementById("examTitle").value = "";
  document.getElementById("examDate").value = today;
  document.getElementById("examNumQ").value = 50;
  document.getElementById("examSheetFormat").value = "compact";
  goToWizardStep(1);
}

/**
 * Navigates to a specific step in the New Exam wizard.
 * @param {number} n - The step number to navigate to (1, 2, or 3).
 */
function goToWizardStep(n) {
  wizard.step = n;
  document.querySelectorAll(".wizard-step").forEach((el) => {
    el.classList.toggle("active", Number(el.dataset.step) === n);
  });
  document.querySelectorAll(".wizard-progress .seg").forEach((el) => {
    const segN = Number(el.dataset.seg);
    el.classList.toggle("done", segN < n);
    el.classList.toggle("current", segN === n);
  });
  if (n === 2) renderWizardAnswerGrid();
  if (n === 3) renderWizardSummary();
}

/**
 * Renders the answer key grid in the wizard step 2.
 * Utilizes wizard.numQuestions and wizard.answerKey to populate the grid.
 */
function renderWizardAnswerGrid() {
  const grid = document.getElementById("wizAnswerGrid");
  grid.innerHTML = "";
  for (let q = 1; q <= wizard.numQuestions; q++) {
    const row = document.createElement("div");
    row.className = "qkey";
    const sel = document.createElement("select");
    sel.className = "field";
    sel.innerHTML =
      '<option value="">—</option>' +
      LayoutUtils.OPTION_LABELS.map(
        (o) =>
          `<option value="${o}" ${wizard.answerKey[q] === o ? "selected" : ""}>${o}</option>`,
      ).join("");
    sel.addEventListener("change", () => {
      if (sel.value) wizard.answerKey[q] = sel.value;
      else delete wizard.answerKey[q];
    });
    row.innerHTML = `<span class="qn">${q}.</span>`;
    row.appendChild(sel);
    grid.appendChild(row);
  }
}

/**
 * Renders the summary of the New Exam wizard in step 3.
 */
function renderWizardSummary() {
  const answeredCount = Object.keys(wizard.answerKey).length;
  document.getElementById("wizSummary").innerHTML = `
    <div class="summary-row"><span class="k">Title</span><span class="v">${escapeHtml(wizard.title) || "—"}</span></div>
    <div class="summary-row"><span class="k">Date</span><span class="v">${wizard.date || "—"}</span></div>
    <div class="summary-row"><span class="k">Questions</span><span class="v">${wizard.numQuestions}</span></div>
    <div class="summary-row"><span class="k">Sheet format</span><span class="v">${wizard.sheetFormat === "compact" ? "Compact (up to 4 per A4)" : "Full page (1 per A4)"}</span></div>
    <div class="summary-row"><span class="k">Answer key set</span><span class="v">${answeredCount}/${wizard.numQuestions}</span></div>
  `;
}

/**
 * Escapes HTML special characters in a string.
 * @param {string} s - The string to escape.
 * @returns {string} The escaped string.
 */
function escapeHtml(s) {
  const d = document.createElement("div");
  d.textContent = s;
  return d.innerHTML;
}

document.getElementById("wizToStep2").addEventListener("click", () => {
  const title = document.getElementById("examTitle").value.trim();
  if (!title) {
    toast("Give the exam a title first");
    return;
  }
  wizard.title = title;
  wizard.date = document.getElementById("examDate").value;
  wizard.numQuestions = Math.max(
    1,
    Math.min(50, parseInt(document.getElementById("examNumQ").value) || 50),
  );
  wizard.sheetFormat = LayoutUtils.normalizeMode(
    document.getElementById("examSheetFormat").value,
  );
  goToWizardStep(2);
});
document
  .getElementById("wizToStep1")
  .addEventListener("click", () => goToWizardStep(1));
document
  .getElementById("wizToStep3")
  .addEventListener("click", () => goToWizardStep(3));
document
  .getElementById("wizToStep2b")
  .addEventListener("click", () => goToWizardStep(2));

// Save the exam to localStorage when the user clicks "Save" in step 3.
document.getElementById("wizSave").addEventListener("click", () => {
  if (!wizard.title) {
    toast("Give the exam a title first");
    goToWizardStep(1);
    return;
  }
  const wasEditing = !!wizard.editingId;
  let savedExam;
  if (wasEditing) {
    savedExam = AppStorage.updateExam(wizard.editingId, {
      title: wizard.title,
      date: wizard.date,
      numQuestions: wizard.numQuestions,
      sheetFormat: wizard.sheetFormat,
      answerKey: wizard.answerKey,
    });
    toast("Exam updated");
  } else {
    savedExam = AppStorage.createExam({
      title: wizard.title,
      date: wizard.date,
      numQuestions: wizard.numQuestions,
      sheetFormat: wizard.sheetFormat,
      answerKey: wizard.answerKey,
    });
    toast("Exam saved");
  }

  // Reset state
  wizard = {
    step: 1,
    title: "",
    date: "",
    numQuestions: 50,
    sheetFormat: "compact",
    answerKey: {},
  };

  // New exam → Scan
  // Edited exam → History
  if (wasEditing) navigateTo("history");
  else navigateToWithParam("scan", savedExam.id);
});

// ================= PRINT PREVIEW =================

/**
 * Collects the current wizard values and (re)renders the print preview.
 */
function refreshPrintPreview() {
  const settings = AppStorage.getSettings();
  const mode = LayoutUtils.normalizeMode(wizard.sheetFormat);
  const copiesBar = document.getElementById("printCopiesBar");
  copiesBar.classList.toggle("show", mode === "compact");
  renderPrintPage({
    institute: settings.instituteName || "",
    examTitle: wizard.title || "Untitled Exam",
    examDate: wizard.date,
    numQuestions: wizard.numQuestions,
    sheetFormat: mode,
    copies: parseInt(document.getElementById("printCopies").value, 10) || 1,
  });
  fitPrintPreview();
}

document.getElementById("wizPrint").addEventListener("click", () => {
  document.getElementById("printOverlay").classList.add("open");
  refreshPrintPreview();
});
document
  .getElementById("printCopies")
  .addEventListener("change", refreshPrintPreview);

/**
 * Renders the printable bubble sheet(s) inside #printPage using the shared layout.js geometry.
 * "full" draws one sheet covering the A4 page; "compact" tiles up to four
 * smaller sheets (2 x 2) on the same A4 page.
 * @param {Object} examParams - The parameters for rendering the print page.
 * @param {string} examParams.institute - The name of the institute.
 * @param {string} examParams.examTitle - The title of the exam.
 * @param {string} examParams.examDate - The date of the exam.
 * @param {number} examParams.numQuestions - The number of questions in the exam.
 * @param {"full"|"compact"} [examParams.sheetFormat] - Sheet format (default "full").
 * @param {number} [examParams.copies] - Number of sheets on the page, 1-4 (compact only).
 */
function renderPrintPage({
  institute,
  examTitle,
  examDate,
  numQuestions,
  sheetFormat = "full",
  copies = 1,
}) {
  const mode = LayoutUtils.normalizeMode(sheetFormat);
  const page = document.getElementById("printPage");
  page.innerHTML = "";
  const mm = (v) => v + "mm";

  const dateStr = examDate
    ? new Date(examDate + "T00:00:00").toLocaleDateString("en-US", {
        month: "long",
        day: "numeric",
        year: "numeric",
      })
    : "";
  const params = {
    institute,
    title: examTitle + (dateStr ? " — " + dateStr : ""),
    numQuestions,
  };

  if (mode === "full") {
    page.appendChild(buildSheet("full", { x: 0, y: 0 }, params));
    return;
  }

  const slots = LayoutUtils.getCompactSlots();
  const count = Math.max(1, Math.min(slots.length, copies));
  const { page: sheetSize } = LayoutUtils.getLayout("compact");
  for (let i = 0; i < count; i++) {
    page.appendChild(buildSheet("compact", slots[i], params));
    // dashed cut guide around the sheet
    const cut = document.createElement("div");
    cut.className = "p-cut";
    cut.style.left = mm(slots[i].x);
    cut.style.top = mm(slots[i].y);
    cut.style.width = mm(sheetSize.width);
    cut.style.height = mm(sheetSize.height);
    page.appendChild(cut);
  }
}

/**
 * Builds a single answer sheet element (markers, header, student box,
 * instructions and bubble grid) positioned at `origin` (mm) on the print page.
 * @param {"full"|"compact"} mode - The sheet format.
 * @param {{x: number, y: number}} origin - Top-left corner of the sheet on the page, in mm.
 * @param {{institute: string, title: string, numQuestions: number}} params
 * @returns {HTMLElement}
 */
function buildSheet(mode, origin, { institute, title, numQuestions }) {
  const L = LayoutUtils.getLayout(mode);
  const mm = (v) => v + "mm";

  const sheet = document.createElement("div");
  sheet.className = "p-sheet " + mode;
  sheet.style.left = mm(origin.x);
  sheet.style.top = mm(origin.y);
  sheet.style.width = mm(L.page.width);
  sheet.style.height = mm(L.page.height);

  // corner markers
  [
    { top: L.marker.inset, left: L.marker.inset },
    { top: L.marker.inset, right: L.marker.inset },
    { bottom: L.marker.inset, right: L.marker.inset },
    { bottom: L.marker.inset, left: L.marker.inset },
  ].forEach((c) => {
    // Using svg to bypass bg-graphics issue on mobile
    const svgNS = "http://www.w3.org/2000/svg";
    const el = document.createElementNS(svgNS, "svg");
    el.classList.add("p-marker");

    el.setAttribute("viewBox", "0 0 100 100");
    el.setAttribute("width", mm(L.marker.size));
    el.setAttribute("height", mm(L.marker.size));

    const rect = document.createElementNS(svgNS, "rect");
    rect.setAttribute("x", "0");
    rect.setAttribute("y", "0");
    rect.setAttribute("width", "100");
    rect.setAttribute("height", "100");
    rect.setAttribute("fill", "#000");

    el.appendChild(rect);

    ["top", "left", "right", "bottom"].forEach((k) => {
      if (c[k] !== undefined) el.style[k] = mm(c[k]);
    });
    sheet.appendChild(el);
  });

  const header = document.createElement("div");
  header.className = "p-header";
  header.style.top = mm(L.header.top);
  header.style.left = mm(L.header.margin);
  header.style.right = mm(L.header.margin);
  header.innerHTML = `<p class="p-institute">${escapeHtml(institute) || "&nbsp;"}</p><p class="p-exam">${escapeHtml(title)}</p><hr class="p-rule">`;
  sheet.appendChild(header);

  const box = document.createElement("div");
  box.className = "p-student-box";
  box.style.top = mm(L.studentInfo.top);
  box.style.height = mm(L.studentInfo.height);
  box.style.left = mm(L.studentInfo.margin);
  box.style.right = mm(L.studentInfo.margin);
  box.innerHTML = `
    <div class="p-field" style="flex:2"><span class="p-label">Name</span><span class="p-fill-line"></span></div>
    <div class="p-field" style="flex:1"><span class="p-label">Index no.</span><span class="p-fill-line"></span></div>
  `;
  sheet.appendChild(box);

  const instr = document.createElement("div");
  instr.className = "p-instr-box";
  instr.style.top = mm(L.noteBox.top);
  instr.style.left = mm(L.noteBox.margin);
  instr.style.right = mm(L.noteBox.margin);
  instr.innerHTML =
    mode === "compact"
      ? `<b>Instructions:</b> Use a dark pen or pencil. Shade one bubble fully per question. Keep the sheet flat when photographing it.`
      : `<b>Instructions:</b> Use a dark pen or pencil. Shade each bubble fully for exactly one answer per question. Keep this sheet flat and unfolded when photographing it for scanning.`;
  sheet.appendChild(instr);

  const bubbles = LayoutUtils.getBubbleGrid(mode).filter(
    (b) => b.question <= numQuestions,
  );
  const seen = new Set();
  bubbles.forEach((b) => {
    if (!seen.has(b.question)) {
      seen.add(b.question);
      const lbl = document.createElement("div");
      lbl.className = "p-qlabel";
      lbl.style.left = mm(b.xMm - L.grid.questionLabelWidth);
      lbl.style.top = mm(b.yMm);
      lbl.textContent = b.question + ".";
      sheet.appendChild(lbl);
    }
    const dot = document.createElement("div");
    dot.className = "p-bubble";
    dot.style.width = mm(L.grid.bubbleDiameter);
    dot.style.height = mm(L.grid.bubbleDiameter);
    dot.style.left = mm(b.xMm);
    dot.style.top = mm(b.yMm);
    dot.textContent = b.option;
    sheet.appendChild(dot);
  });

  return sheet;
}

/**
 * Scales the true-size (210mm) print page down to fit the preview pane,
 * without affecting the actual '@media' print output.
 */
function fitPrintPreview() {
  const wrap = document.querySelector(".print-preview-wrap");
  const pageEl = document.getElementById("printPage");
  const availableWidth = wrap.clientWidth - 20;
  // 210mm = 210 * 3.7795 px (1mm = 3.7795 px at 96dpi)
  const pageWidthPx = pageEl.getBoundingClientRect().width || 210 * 3.7795;
  const scale = Math.min(1, availableWidth / (210 * 3.7795));
  pageEl.style.transform = `scale(${scale})`;
  let scaler = document.querySelector(".print-page-scaler");
  if (!scaler) {
    scaler = document.createElement("div");
    scaler.className = "print-page-scaler";
    pageEl.parentNode.insertBefore(scaler, pageEl);
    scaler.appendChild(pageEl);
  }
  scaler.style.width = 210 * 3.7795 * scale + "px";
  scaler.style.height = 297 * 3.7795 * scale + "px";
}
// Fit page again on resize while the overlay is open.
window.addEventListener("resize", () => {
  if (document.getElementById("printOverlay").classList.contains("open"))
    fitPrintPreview();
});

/**
 * Closes the print overlay
 */
function closePrintOverlay() {
  document.getElementById("printOverlay").classList.remove("open");
}

document
  .getElementById("printCloseBtn")
  .addEventListener("click", closePrintOverlay);
document
  .getElementById("printCloseBtn2")
  .addEventListener("click", closePrintOverlay);
document
  .getElementById("printNowBtn")
  .addEventListener("click", () => window.print());

// ================= EXAMS HISTORY =================

/**
 * Renders the list of saved exams in the history screen.
 */
function renderHistory() {
  const exams = AppStorage.getExams();
  const list = document.getElementById("historyList");
  const empty = document.getElementById("historyEmpty");
  list.innerHTML = "";
  empty.style.display = exams.length ? "none" : "block";

  exams.forEach((exam) => {
    const row = document.createElement("div");
    row.className = "card exam-row";
    const dateStr = exam.date
      ? new Date(exam.date + "T00:00:00").toLocaleDateString(undefined, {
          month: "short",
          day: "numeric",
          year: "numeric",
        })
      : "—";
    row.innerHTML = `
      <div class="exam-icon">
        <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3v4a1 1 0 0 0 1 1h4"/><path d="M17 21H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7l5 5v11a2 2 0 0 1-2 2Z"/></svg>
      </div>
      <div class="exam-info">
        <div class="exam-title">${escapeHtml(exam.title)}</div>
        <div class="exam-meta">${dateStr} · ${exam.numQuestions} questions · ${exam.results.length} scanned</div>
      </div>
      <div class="exam-actions">
        <button class="icon-btn" data-edit="${exam.id}" aria-label="Edit">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
        </button>
        <button class="icon-btn" data-delete="${exam.id}" aria-label="Delete">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 6"/></svg>
        </button>
      </div>
    `;
    row.addEventListener("click", (e) => {
      if (e.target.closest("[data-edit]") || e.target.closest("[data-delete]"))
        return;
      navigateToWithParam("scan", exam.id);
    });
    // --- Action [Edit] button ---
    row
      .querySelector("[data-edit]")
      .addEventListener("click", () => editExam(exam.id));
    // --- Action [Delete] button ---
    row.querySelector("[data-delete]").addEventListener("click", () => {
      if (
        !confirm(
          `Delete "${exam.title}" and its ${exam.results.length} saved result(s)? This can't be undone.`,
        )
      )
        return;
      AppStorage.deleteExam(exam.id);
      renderHistory();
      toast("Exam deleted");
    });
    // Append the row to the list
    list.appendChild(row);
  });
}

/**
 * Opens the exam editor for the specified exam.
 * @param {string|number} id - The ID of the exam to edit.
 * @returns {void}
 */
function editExam(id) {
  const exam = AppStorage.getExam(id);
  if (!exam) return;
  wizard = {
    step: 1,
    title: exam.title,
    date: exam.date,
    numQuestions: exam.numQuestions,
    sheetFormat: LayoutUtils.normalizeMode(exam.sheetFormat),
    answerKey: { ...exam.answerKey },
    editingId: id,
  };
  document.getElementById("examTitle").value = exam.title;
  document.getElementById("examDate").value = exam.date;
  document.getElementById("examNumQ").value = exam.numQuestions;
  document.getElementById("examSheetFormat").value = wizard.sheetFormat;
  navigateTo("new-exam");
  goToWizardStep(1);
}

// ================= SETTINGS =================
/**
 * Renders the settings screen with current values from localStorage.
 */
function renderSettings() {
  const s = AppStorage.getSettings();
  document.getElementById("setInstitute").value = s.instituteName;
  document.getElementById("setDarkThreshold").value = s.darkThreshold;
  document.getElementById("setSeparationMin").value = s.separationMin;
}

document.getElementById("setInstitute").addEventListener("change", (e) => {
  AppStorage.saveSettings({ instituteName: e.target.value.trim() });
});
document.getElementById("setDarkThreshold").addEventListener("change", (e) => {
  AppStorage.saveSettings({ darkThreshold: Number(e.target.value) });
});
document.getElementById("setSeparationMin").addEventListener("change", (e) => {
  AppStorage.saveSettings({ separationMin: Number(e.target.value) });
});
document
  .getElementById("resetDetectionDefaults")
  .addEventListener("click", () => {
    AppStorage.saveSettings({ darkThreshold: 150, separationMin: 18 });
    renderSettings();
    toast("Detection settings reset");
  });
document.getElementById("clearDataBtn").addEventListener("click", () => {
  if (
    !confirm(
      "This deletes every saved exam, answer key, and result on this device. Continue?",
    )
  )
    return;
  AppStorage.clearAllData();
  toast("All data cleared");
  renderSettings();
  navigateTo("home");
});

// ================= WIRE UP SCREEN ACTIVATION =================
document.addEventListener("screenshow", (e) => {
  const { name } = e.detail;
  if (name === "new-exam" && wizard.step === 1 && !wizard.editingId)
    resetWizard();
  if (name === "history") renderHistory();
  if (name === "settings") renderSettings();
});

// Reset the "just navigated fresh" wizard state whenever leaving new-exam
// back to home via the top back button (not via Save, which already reset).
document.querySelectorAll("#screen-new-exam [data-back]").forEach((btn) => {
  btn.addEventListener("click", () => {
    wizard = {
      step: 1,
      title: "",
      date: "",
      numQuestions: 50,
      sheetFormat: "compact",
      answerKey: {},
    };
  });
});
