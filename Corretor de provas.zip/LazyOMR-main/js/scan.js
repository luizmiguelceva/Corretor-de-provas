/**
 * scan.js - Handles the scanning workflow, including camera access, image processing, and result management.
 * Lazy loads OpenCV.js for corner detection, perspective transformation, and bubble scoring.
 *
 * (c) 2026 Dilshan-H (https://github.com/Dilshan-H)
 * Licensed under MIT
 */

// ================= STATE =================
let scanCtx = { examId: null, exam: null };
let cvReady = false;
let cvLoadPromise = null;

let stream = null;
let camProcessing = false;
let lastStableQuad = null;
let stableFrameCount = 0;
const STABLE_FRAMES_REQUIRED = 6;
const STABLE_MOVE_PX = 6;
const PROCESS_INTERVAL_MS = 150;
let lastProcessTime = 0;

let pendingCapture = null; // { perQuestion, score, total, canvas }

/**
 * Sheet format ("full" | "compact") of the exam being scanned.
 * Exams saved before the compact format existed have no format -> "full".
 * @returns {"full"|"compact"}
 */
function currentSheetMode() {
  return LayoutUtils.normalizeMode(scanCtx.exam && scanCtx.exam.sheetFormat);
}

// ================= OPENCV LAZY LOAD =================

/**
 * Ensures that OpenCV.js is loaded and initialized.
 * @returns {Promise} A promise that resolves when OpenCV.js is ready.
 */
function ensureOpenCv() {
  if (window.cv && window.cv.Mat) {
    cvReady = true;
    return Promise.resolve();
  }
  if (cvLoadPromise) return cvLoadPromise;
  cvLoadPromise = new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = "https://docs.opencv.org/4.9.0/opencv.js";
    script.async = true;
    script.onload = () => {
      // wait for OpenCV onRuntimeInitialized callback
      window.cv["onRuntimeInitialized"] = () => {
        cvReady = true;
        resolve();
      };
    };
    script.onerror = () =>
      reject(new Error("Could not load OpenCV.js — check your connection."));
    document.head.appendChild(script);
  });
  return cvLoadPromise;
}

// ================= SCREEN ACTIVATION =================
document.addEventListener("screenshow", (e) => {
  const { name, param } = e.detail;
  if (name !== "scan") {
    teardownCamera();
    return;
  }
  if (param) {
    scanCtx.examId = param;
    scanCtx.exam = AppStorage.getExam(param);
    if (!scanCtx.exam) {
      toast("Exam not found");
      navigateTo("history");
      return;
    }
    showPhase("hub");
    renderHub();
  } else {
    scanCtx = { examId: null, exam: null };
    showPhase("pick");
    renderScanPick();
  }
});

/**
 * Sets the current scan phase on the UI
 * @param {string} phase
 */
function showPhase(phase) {
  document.getElementById("scanPickPhase").style.display =
    phase === "pick" ? "block" : "none";
  document.getElementById("scanHubPhase").style.display =
    phase === "hub" ? "block" : "none";
  document.getElementById("scanAfterSavePhase").style.display =
    phase === "afterSave" ? "block" : "none";
}

// ================= EXAM PICKER =================

/**
 * Renders the exam picker list in the scan phase.
 */
function renderScanPick() {
  const exams = AppStorage.getExams();
  const list = document.getElementById("scanPickList");
  const empty = document.getElementById("scanPickEmpty");
  list.innerHTML = "";
  empty.style.display = exams.length ? "none" : "block";
  exams.forEach((exam) => {
    const row = document.createElement("div");
    row.className = "card exam-row";
    row.innerHTML = `
      <div class="exam-icon">
        <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="8" y="9" width="8" height="6" rx="1"/><path d="M4 8V6a2 2 0 0 1 2-2h2M4 16v2a2 2 0 0 0 2 2h2M20 8V6a2 2 0 0 0-2-2h-2M20 16v2a2 2 0 0 1-2 2h-2"/></svg>
      </div>
      <div class="exam-info">
        <div class="exam-title">${escapeHtml(exam.title)}</div>
        <div class="exam-meta">${exam.numQuestions} questions · ${exam.results.length} scanned</div>
      </div>
    `;
    row.addEventListener("click", () => navigateToWithParam("scan", exam.id));
    list.appendChild(row);
  });
}

// ================= HUB (exam summary + results + rank) =================

/**
 * Renders the hub view for the current exam,
 * showing its title, date, number of questions, and a table of scanned results.
 */
function renderHub() {
  const exam = scanCtx.exam;
  document.getElementById("hubTitle").textContent = exam.title;
  const dateStr = exam.date
    ? new Date(exam.date + "T00:00:00").toLocaleDateString(undefined, {
        month: "short",
        day: "numeric",
        year: "numeric",
      })
    : "—";
  document.getElementById("hubMeta").textContent =
    `${dateStr} · ${exam.numQuestions} questions · ${exam.results.length} scanned`;

  const tbody = document.querySelector("#hubResultsTable tbody");
  tbody.innerHTML = "";
  const sorted = [...exam.results].sort((a, b) => b.score - a.score);
  document.getElementById("hubResultsEmpty").style.display = sorted.length
    ? "none"
    : "block";
  document.getElementById("hubResultsWrap").style.display = sorted.length
    ? "block"
    : "none";
  sorted.forEach((r, i) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${i + 1}</td>
      <td>${escapeHtml(r.name || "—")}</td>
      <td>${escapeHtml(r.index || "—")}</td>
      <td>${r.score}/${r.total}</td>
      <td><button class="icon-btn sm" data-del="${r.id}" aria-label="Delete"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 6"/></svg></button></td>
    `;
    tr.querySelector("[data-del]").addEventListener("click", () => {
      if (!confirm("Delete this result?")) return;
      AppStorage.deleteResultFromExam(exam.id, r.id);
      scanCtx.exam = AppStorage.getExam(exam.id);
      renderHub();
    });
    tbody.appendChild(tr);
  });
}

document.getElementById("hubScanBtn").addEventListener("click", openCamera);
document
  .getElementById("hubExportBtn")
  .addEventListener("click", exportExamCsv);

/**
 * Exports the current exam's results to a CSV file.
 */
function exportExamCsv() {
  const exam = scanCtx.exam;
  if (!exam.results.length) {
    toast("No results to export yet");
    return;
  }
  const header = ["Name", "Index", "Score", "Total"];
  const rows = exam.results.map((r) => [r.name, r.index, r.score, r.total]);
  const csv = [header, ...rows]
    .map((row) => row.map(csvEscape).join(","))
    .join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `${(exam.title || "exam").replace(/[^a-z0-9]+/gi, "_")}_results.csv`;
  a.click();
}

/**
 * Escapes a value for use in a CSV file.
 * @param {string} v - The value to escape.
 * @returns {string} The escaped value.
 */
function csvEscape(v) {
  const s = String(v ?? "");
  return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}

/**
 * Escapes a string for use in HTML.
 * @param {string} s - The string to escape.
 * @returns {string} The escaped string.
 */
function escapeHtml(s) {
  const d = document.createElement("div");
  d.textContent = s ?? "";
  return d.innerHTML;
}

// ================= CAMERA =================
const video = document.getElementById("video");
const cameraOverlay = document.getElementById("cameraOverlay");
const cameraToastEl = document.getElementById("cameraToast");
const cameraCaptureBtn = document.getElementById("cameraCaptureBtn");

/**
 * Sets the status message for the camera.
 * @param {*} msg - The status message to display.
 */
function cameraStatus(msg) {
  cameraToastEl.textContent = msg;
}

/**
 * Opens the camera and starts the scanning process.
 */
async function openCamera() {
  document.getElementById("cameraExamName").textContent = scanCtx.exam.title;
  cameraOverlay.classList.add("open");
  cameraCaptureBtn.disabled = true;
  stableFrameCount = 0;
  lastStableQuad = null;
  cameraStatus("Loading detector…");
  try {
    await ensureOpenCv();
  } catch (err) {
    cameraStatus("Detector failed to load — you can still upload a photo.");
  }
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: "environment",
        width: { ideal: 1280 },
        height: { ideal: 1280 },
      },
    });
    video.srcObject = stream;
    await video.play();
    cameraStatus("Point the camera at the sheet");
    requestAnimationFrame(processLoop);
  } catch (err) {
    cameraStatus("Camera failed to open — you can still upload a photo.");
  }
}

/**
 * Closes the camera and stops the scanning process.
 */
function closeCamera() {
  teardownCamera();
  showPhase("hub");
}

/**
 * Aborts the camera stream and resets the scanning state.
 */
function teardownCamera() {
  cameraOverlay.classList.remove("open");
  if (stream) {
    stream.getTracks().forEach((t) => t.stop());
    stream = null;
  }
  camProcessing = false;
}
document
  .getElementById("cameraCloseBtn")
  .addEventListener("click", closeCamera);
document
  .getElementById("cameraCaptureBtn")
  .addEventListener("click", () => captureAndProcess(searchScaleCache || 1));

const searchCanvas = document.createElement("canvas");
const SEARCH_WIDTH = 480;
let searchScaleCache = 1;

/**
 * The main processing loop for the camera.
 * @param {*} ts - The timestamp of the current frame.
 */
function processLoop(ts) {
  if (!cameraOverlay.classList.contains("open")) return; // camera closed, stop looping
  if (!camProcessing && cvReady && video.videoWidth) {
    if (!lastProcessTime || ts - lastProcessTime > PROCESS_INTERVAL_MS) {
      lastProcessTime = ts;
      runMarkerSearch();
    }
  }
  requestAnimationFrame(processLoop);
}

/**
 * Runs the marker search algorithm on the current video frame.
 */
function runMarkerSearch() {
  const scale = SEARCH_WIDTH / video.videoWidth;
  searchScaleCache = scale;
  searchCanvas.width = SEARCH_WIDTH;
  searchCanvas.height = Math.round(video.videoHeight * scale);
  searchCanvas
    .getContext("2d")
    .drawImage(video, 0, 0, searchCanvas.width, searchCanvas.height);

  let src;
  try {
    src = cv.imread(searchCanvas);
  } catch (e) {
    return;
  }
  const found = findCornerMarkers(src);
  src.delete();

  if (found.allFound) {
    const moved = lastStableQuad
      ? maxDrift(lastStableQuad, found.points)
      : Infinity;
    stableFrameCount = moved < STABLE_MOVE_PX ? stableFrameCount + 1 : 1;
    lastStableQuad = found.points;
    cameraCaptureBtn.disabled = false;
    if (stableFrameCount >= STABLE_FRAMES_REQUIRED) {
      cameraStatus("Locked — capturing…");
      captureAndProcess(scale);
      return;
    }
    cameraStatus(
      `Hold steady… (${stableFrameCount}/${STABLE_FRAMES_REQUIRED})`,
    );
  } else {
    stableFrameCount = 0;
    lastStableQuad = null;
    cameraCaptureBtn.disabled = true;
    const missing = ["topLeft", "topRight", "bottomRight", "bottomLeft"].filter(
      (k) => !found.quadrants[k],
    ).length;
    cameraStatus(
      missing === 4
        ? currentSheetMode() === "compact"
          ? "Point the camera at one sheet (cut apart or fill the frame)"
          : "Point the camera at the sheet"
        : `Move the sheet fully into frame (${4 - missing}/4 corners found)`,
    );
  }
}

/**
 * Calculates the maximum drift between two sets of points.
 * @param {*} a
 * @param {*} b
 * @returns {number} The maximum drift in pixels.
 */
function maxDrift(a, b) {
  let m = 0;
  for (let i = 0; i < 4; i++)
    m = Math.max(m, Math.hypot(a[i].x - b[i].x, a[i].y - b[i].y));
  return m;
}

/**
 * Finds the corner square markers in the given image.
 * @param {*} src - The source image.
 * @returns {Object} An object containing the found points and quadrant status.
 */
function findCornerMarkers(src) {
  const gray = new cv.Mat();
  cv.cvtColor(src, gray, cv.COLOR_RGBA2GRAY);
  const blurred = new cv.Mat();
  cv.GaussianBlur(gray, blurred, new cv.Size(5, 5), 0);
  const thresh = new cv.Mat();
  cv.threshold(blurred, thresh, 0, 255, cv.THRESH_BINARY_INV + cv.THRESH_OTSU);

  const contours = new cv.MatVector();
  const hierarchy = new cv.Mat();
  cv.findContours(
    thresh,
    contours,
    hierarchy,
    cv.RETR_LIST,
    cv.CHAIN_APPROX_SIMPLE,
  );

  const w = src.cols,
    h = src.rows;
  const minArea = 0.0004 * w * h;
  const maxArea = 0.03 * w * h;
  const best = {
    topLeft: null,
    topRight: null,
    bottomRight: null,
    bottomLeft: null,
  };

  for (let i = 0; i < contours.size(); i++) {
    const cnt = contours.get(i);
    const area = cv.contourArea(cnt);
    if (area < minArea || area > maxArea) {
      cnt.delete();
      continue;
    }
    const peri = cv.arcLength(cnt, true);
    const approx = new cv.Mat();
    cv.approxPolyDP(cnt, approx, 0.04 * peri, true);
    const isQuad = approx.rows === 4;
    const rect = cv.boundingRect(cnt);
    const aspect = rect.width / rect.height;
    const squareish = aspect > 0.7 && aspect < 1.4;
    if (isQuad && squareish) {
      const cx = rect.x + rect.width / 2;
      const cy = rect.y + rect.height / 2;
      const quadrant =
        cx < w / 2
          ? cy < h / 2
            ? "topLeft"
            : "bottomLeft"
          : cy < h / 2
            ? "topRight"
            : "bottomRight";
      if (!best[quadrant] || area > best[quadrant].area)
        best[quadrant] = { area, cx, cy };
    }
    approx.delete();
    cnt.delete();
  }
  gray.delete();
  blurred.delete();
  thresh.delete();
  contours.delete();
  hierarchy.delete();

  const allFound =
    best.topLeft && best.topRight && best.bottomRight && best.bottomLeft;
  const points = allFound
    ? [best.topLeft, best.topRight, best.bottomRight, best.bottomLeft].map(
        (p) => ({ x: p.cx, y: p.cy }),
      )
    : null;
  return {
    allFound,
    points,
    quadrants: {
      topLeft: !!best.topLeft,
      topRight: !!best.topRight,
      bottomRight: !!best.bottomRight,
      bottomLeft: !!best.bottomLeft,
    },
  };
}

/**
 * Captures the current video frame and processes it for corner marker detection.
 * @param {number} searchScale - The scale at which to search for markers.
 */
function captureAndProcess(searchScale) {
  if (camProcessing || !lastStableQuad) return;
  camProcessing = true;
  const fullCanvas = document.createElement("canvas");
  fullCanvas.width = video.videoWidth;
  fullCanvas.height = video.videoHeight;
  fullCanvas.getContext("2d").drawImage(video, 0, 0);
  const scaleUp = 1 / searchScale;
  const fullResQuad = lastStableQuad.map((p) => ({
    x: p.x * scaleUp,
    y: p.y * scaleUp,
  }));
  runFullPipeline(fullCanvas, fullResQuad);
}

// ---- Upload-photo fallback ----
document
  .getElementById("cameraUploadBtn")
  .addEventListener("click", () =>
    document.getElementById("cameraFileInput").click(),
  );
document
  .getElementById("cameraFileInput")
  .addEventListener("change", async (e) => {
    const file = e.target.files[0];
    e.target.value = "";
    if (!file) return;
    cameraStatus("Loading detector…");
    try {
      await ensureOpenCv();
    } catch (err) {
      toast(err.message);
      return;
    }
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = img.width;
      canvas.height = img.height;
      canvas.getContext("2d").drawImage(img, 0, 0);
      let src;
      try {
        src = cv.imread(canvas);
      } catch (err) {
        toast("Sorry, could not read that image.");
        return;
      }
      const found = findCornerMarkers(src);
      src.delete();
      if (!found.allFound) {
        toast(
          "Could not find all 4 corner markers - try a clearer, straighter photo.",
        );
        return;
      }
      camProcessing = false;
      runFullPipeline(canvas, found.points);
    };
    img.src = URL.createObjectURL(file);
  });

// ================= WARP + SCORE + ANNOTATE =================

/**
 * Runs the full image processing pipeline.
 * @param {*} sourceCanvas - The canvas containing the source image.
 * @param {*} quad - The quadrilateral points for perspective transformation.
 */
function runFullPipeline(sourceCanvas, quad) {
  const mode = currentSheetMode();
  const canonical = LayoutUtils.getCanonicalSize(mode);
  const dstPoints = LayoutUtils.getCanonicalMarkerCenters(mode);

  const src = cv.imread(sourceCanvas);
  const srcTri = cv.matFromArray(
    4,
    1,
    cv.CV_32FC2,
    quad.flatMap((p) => [p.x, p.y]),
  );
  const dstTri = cv.matFromArray(
    4,
    1,
    cv.CV_32FC2,
    dstPoints.flatMap((p) => [p.x, p.y]),
  );
  const M = cv.getPerspectiveTransform(srcTri, dstTri);
  const warped = new cv.Mat();
  cv.warpPerspective(
    src,
    warped,
    M,
    new cv.Size(canonical.width, canonical.height),
  );

  const gray = new cv.Mat();
  cv.cvtColor(warped, gray, cv.COLOR_RGBA2GRAY);

  const settings = AppStorage.getSettings();
  const perQuestion = scoreBubbles(
    gray,
    settings,
    scanCtx.exam.numQuestions,
    mode,
  );
  const { classified, score, total } = classifyAll(
    perQuestion,
    scanCtx.exam.answerKey,
  );

  const outCanvas = document.createElement("canvas");
  cv.imshow(outCanvas, warped);
  drawAnnotations(outCanvas, classified, mode);

  pendingCapture = { classified, score, total, canvas: outCanvas };

  // Cleanup
  src.delete();
  srcTri.delete();
  dstTri.delete();
  M.delete();
  warped.delete();
  gray.delete();
  camProcessing = false;
  teardownCamera();

  // Show the review screen
  showReview();
}

/**
 * Scores the bubbles in the given grayscale image.
 * @param {*} grayMat - The grayscale image matrix.
 * @param {*} settings - The scoring settings.
 * @param {*} numQuestions - The number of questions to score.
 * @param {"full"|"compact"} [mode] - The sheet format that was scanned.
 * @returns {Object} The scored bubbles.
 */
function scoreBubbles(grayMat, settings, numQuestions, mode = "full") {
  const bubbles = LayoutUtils.getBubbleGridPx(mode).filter(
    (b) => b.question <= numQuestions,
  );
  const radius = Math.round(
    LayoutUtils.mmToPx(LayoutUtils.getLayout(mode).grid.bubbleDiameter, mode) *
      0.35,
  );
  const byQuestion = {};
  bubbles.forEach((b) => {
    if (!byQuestion[b.question]) byQuestion[b.question] = [];
    byQuestion[b.question].push({
      option: b.option,
      x: b.x,
      y: b.y,
      fill: sampleDarkness(grayMat, b.x, b.y, radius),
    });
  });

  const result = {};
  Object.entries(byQuestion).forEach(([q, opts]) => {
    const sorted = [...opts].sort((a, b) => a.fill - b.fill);
    const darkest = sorted[0],
      second = sorted[1];
    const gap = second.fill - darkest.fill;
    let status, option;
    if (darkest.fill < settings.darkThreshold) {
      option = darkest.option;
      status = gap < settings.separationMin ? "doubt" : "answered";
    } else {
      option = null;
      status = "blank";
    }
    result[q] = { option, status, bubbles: opts };
  });
  return result;
}

/**
 * Samples the darkness of a region in the grayscale image.
 * @param {*} grayMat - The grayscale image matrix.
 * @param {*} cx - The x-coordinate of the center point.
 * @param {*} cy - The y-coordinate of the center point.
 * @param {*} radius - The radius of the region to sample.
 * @returns {number} The average darkness value.
 */
function sampleDarkness(grayMat, cx, cy, radius) {
  const x0 = Math.max(0, cx - radius),
    y0 = Math.max(0, cy - radius);
  const w = Math.min(radius * 2, grayMat.cols - x0);
  const h = Math.min(radius * 2, grayMat.rows - y0);
  const roi = grayMat.roi(new cv.Rect(x0, y0, w, h));
  const mean = cv.mean(roi)[0];
  roi.delete();
  return mean;
}

/**
 * Combines detected bubble status with the answer key to get a final
 * per-question category: 'correct' | 'incorrect' | 'unanswered' | 'doubt' | null
 * @param {*} perQuestion - The per-question results.
 * @param {*} answerKey - The answer key.
 * @returns {Object} The classified results.
 */
function classifyAll(perQuestion, answerKey) {
  const classified = {};
  let score = 0,
    total = 0;
  Object.entries(perQuestion).forEach(([q, r]) => {
    const correctOption = answerKey[q];
    let category = null;
    if (correctOption) {
      total++;
      if (r.status === "blank") category = "unanswered";
      else if (r.status === "doubt") category = "doubt";
      else category = r.option === correctOption ? "correct" : "incorrect";
      if (category === "correct") score++;
    }
    classified[q] = { ...r, category, correctOption };
  });
  return { classified, score, total };
}

/**
 * Draws annotations on the canvas based on the classified results.
 * @param {*} canvas - The HTML canvas element.
 * @param {*} classified - The classified results.
 * @param {"full"|"compact"} [mode] - The sheet format that was scanned.
 */
function drawAnnotations(canvas, classified, mode = "full") {
  const ctx = canvas.getContext("2d");
  const style = getComputedStyle(document.documentElement);
  const colors = {
    correct: style.getPropertyValue("--sem-correct").trim(),
    incorrect: style.getPropertyValue("--sem-incorrect").trim(),
    unanswered: style.getPropertyValue("--sem-unanswered").trim(),
    doubt: style.getPropertyValue("--sem-doubt").trim(),
  };
  const bubbleR =
    LayoutUtils.mmToPx(LayoutUtils.getLayout(mode).grid.bubbleDiameter, mode) /
    2;
  const pad = bubbleR * 0.55;
  ctx.lineWidth = mode === "compact" ? 2.6 : 2.2;
  ctx.lineJoin = "round";

  Object.values(classified).forEach((r) => {
    if (!r.category) return;
    if (r.category === "unanswered" || r.category === "doubt") {
      const xs = r.bubbles.map((b) => b.x),
        ys = r.bubbles.map((b) => b.y);
      const x0 = Math.min(...xs) - bubbleR - pad,
        x1 = Math.max(...xs) + bubbleR + pad;
      const y0 = Math.min(...ys) - bubbleR - pad,
        y1 = Math.max(...ys) + bubbleR + pad;
      strokeRoundedRect(ctx, x0, y0, x1 - x0, y1 - y0, 6, colors[r.category]);
    } else if (r.category === "correct") {
      const b = r.bubbles.find((o) => o.option === r.option);
      strokeRoundedRect(
        ctx,
        b.x - bubbleR - pad,
        b.y - bubbleR - pad,
        (bubbleR + pad) * 2,
        (bubbleR + pad) * 2,
        bubbleR,
        colors.correct,
      );
    } else if (r.category === "incorrect") {
      const marked = r.bubbles.find((o) => o.option === r.option);
      const correct = r.bubbles.find((o) => o.option === r.correctOption);
      strokeRoundedRect(
        ctx,
        marked.x - bubbleR - pad,
        marked.y - bubbleR - pad,
        (bubbleR + pad) * 2,
        (bubbleR + pad) * 2,
        bubbleR,
        colors.incorrect,
      );
      if (correct)
        strokeRoundedRect(
          ctx,
          correct.x - bubbleR - pad,
          correct.y - bubbleR - pad,
          (bubbleR + pad) * 2,
          (bubbleR + pad) * 2,
          bubbleR,
          colors.correct,
          0.55,
        );
    }
  });
}

/**
 * Draws a rounded rectangle on the canvas.
 * @param {*} ctx - The 2D rendering context.
 * @param {*} x - The x-coordinate of the top-left corner.
 * @param {*} y - The y-coordinate of the top-left corner.
 * @param {*} w - The width of the rectangle.
 * @param {*} h - The height of the rectangle.
 * @param {*} r - The radius of the rounded corners.
 * @param {*} color
 * @param {*} alpha
 */
function strokeRoundedRect(ctx, x, y, w, h, r, color, alpha = 1) {
  ctx.globalAlpha = alpha;
  ctx.strokeStyle = color;
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
  ctx.stroke();
  ctx.globalAlpha = 1;
}

// ================= REVIEW SCREEN =================
const reviewOverlay = document.getElementById("reviewOverlay");
const reviewCanvas = document.getElementById("reviewCanvas");

function showReview() {
  const ctx = reviewCanvas.getContext("2d");
  reviewCanvas.width = pendingCapture.canvas.width;
  reviewCanvas.height = pendingCapture.canvas.height;
  ctx.drawImage(pendingCapture.canvas, 0, 0);

  const counts = { correct: 0, incorrect: 0, unanswered: 0, doubt: 0 };
  Object.values(pendingCapture.classified).forEach((r) => {
    if (r.category) counts[r.category]++;
  });
  document.getElementById("reviewStats").textContent =
    `${pendingCapture.score}/${pendingCapture.total} · ${counts.unanswered} unanswered · ${counts.doubt} to check`;

  reviewOverlay.classList.add("open");
}

document.getElementById("reviewRetakeBtn").addEventListener("click", () => {
  reviewOverlay.classList.remove("open");
  pendingCapture = null;
  openCamera();
});

document.getElementById("reviewConfirmBtn").addEventListener("click", () => {
  document.getElementById("confirmName").value = "";
  document.getElementById("confirmIndex").value = "";
  document.getElementById("confirmScore").value = pendingCapture.score;
  document.getElementById("confirmScore").max = pendingCapture.total;
  openSheet("confirmOverlay", "confirmSheet");
});

document
  .getElementById("reviewHelpBtn")
  .addEventListener("click", () => openSheet("legendOverlay", "legendSheet"));

// ---- Zoom ----
const zoomOverlay = document.getElementById("zoomOverlay");
const zoomImage = document.getElementById("zoomImage");
let zoomScale = 1,
  zoomX = 0,
  zoomY = 0;

document.getElementById("reviewCanvasWrap").addEventListener("click", () => {
  zoomImage.src = reviewCanvas.toDataURL("image/png");
  zoomScale = 1;
  zoomX = 0;
  zoomY = 0;
  applyZoomTransform();
  zoomOverlay.classList.add("open");
});
document
  .getElementById("zoomCloseBtn")
  .addEventListener("click", () => zoomOverlay.classList.remove("open"));

/**
 * Applies the current zoom scale and translation to the zoom image.
 */
function applyZoomTransform() {
  zoomImage.style.transform = `translate(${zoomX}px, ${zoomY}px) scale(${zoomScale})`;
}
let lastTap = 0;
document.getElementById("zoomViewport").addEventListener("click", (e) => {
  const now = Date.now();
  if (now - lastTap < 300) {
    if (zoomScale === 1) {
      zoomScale = 2.5;
    } else {
      zoomScale = 1;
      zoomX = 0;
      zoomY = 0;
    }
    applyZoomTransform();
  }
  lastTap = now;
});
let dragging = false,
  dragStartX = 0,
  dragStartY = 0,
  dragOrigX = 0,
  dragOrigY = 0;
const zoomViewportEl = document.getElementById("zoomViewport");
zoomViewportEl.addEventListener("pointerdown", (e) => {
  if (zoomScale === 1) return;
  dragging = true;
  dragStartX = e.clientX;
  dragStartY = e.clientY;
  dragOrigX = zoomX;
  dragOrigY = zoomY;
});
window.addEventListener("pointermove", (e) => {
  if (!dragging) return;
  zoomX = dragOrigX + (e.clientX - dragStartX);
  zoomY = dragOrigY + (e.clientY - dragStartY);
  applyZoomTransform();
});
window.addEventListener("pointerup", () => {
  dragging = false;
});

// ---- Bottom sheet swipe tracking (using setupSheetSwipeGesture from app.js) ----

// ---- Generic bottom-sheet open/close helpers ----

/**
 * Opens the specified overlay and sheet.
 * @param {string} overlayId - The ID of the overlay element
 * @param {string} sheetId - The ID of the sheet element
 */
function openSheet(overlayId, sheetId) {
  // close any other open sheet first
  ["confirmOverlay", "legendOverlay"].forEach((oid) => {
    if (oid !== overlayId)
      document.getElementById(oid).classList.remove("open");
  });
  ["confirmSheet", "legendSheet"].forEach((sid) => {
    if (sid !== sheetId) document.getElementById(sid).classList.remove("open");
  });
  document.getElementById(overlayId).classList.add("open");
  document.getElementById(sheetId).classList.add("open");
}

/**
 * Closes the specified overlay and sheet.
 * @param {string} overlayId - The ID of the overlay element
 * @param {string} sheetId - The ID of the sheet element
 */
function closeSheet(overlayId, sheetId) {
  document.getElementById(overlayId).classList.remove("open");
  document.getElementById(sheetId).classList.remove("open");
}
document
  .getElementById("confirmOverlay")
  .addEventListener("click", () =>
    closeSheet("confirmOverlay", "confirmSheet"),
  );
document
  .getElementById("confirmCancelBtn")
  .addEventListener("click", () =>
    closeSheet("confirmOverlay", "confirmSheet"),
  );
document
  .getElementById("legendOverlay")
  .addEventListener("click", () => closeSheet("legendOverlay", "legendSheet"));

// Setup swipe-to-close gestures on both sheets
setupSheetSwipeGesture("confirmSheet", "confirmOverlay", () =>
  closeSheet("confirmOverlay", "confirmSheet"),
);
setupSheetSwipeGesture("legendSheet", "legendOverlay", () =>
  closeSheet("legendOverlay", "legendSheet"),
);

// ================= CONFIRM & SAVE =================
document.getElementById("confirmSaveBtn").addEventListener("click", () => {
  const name = document.getElementById("confirmName").value.trim();
  const index = document.getElementById("confirmIndex").value.trim();
  if (!name && !index) {
    toast("Enter a name or index number");
    return;
  }
  const total = pendingCapture.total;
  const score = Math.max(
    0,
    Math.min(
      total,
      parseInt(document.getElementById("confirmScore").value, 10) || 0,
    ),
  );

  AppStorage.addResultToExam(scanCtx.examId, { name, index, score, total });
  scanCtx.exam = AppStorage.getExam(scanCtx.examId);
  closeSheet("confirmOverlay", "confirmSheet");
  reviewOverlay.classList.remove("open");
  pendingCapture = null;

  document.getElementById("afterSaveSub").textContent =
    `Saved — score ${score}/${total}`;
  showPhase("afterSave");
});

document.getElementById("afterSaveNext").addEventListener("click", () => {
  showPhase("hub");
  openCamera();
});
document.getElementById("afterSaveEnd").addEventListener("click", () => {
  renderHub();
  showPhase("hub");
});
