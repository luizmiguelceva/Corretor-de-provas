/**
 * storage.js - Helpers for reading/writing app data to localStorage.
 *
 * (c) 2026 Dilshan-H (https://github.com/Dilshan-H)
 * Licensed under MIT
 */

const LS_EXAMS = "lazyomr_exams";
const LS_SETTINGS = "lazyomr_settings";

const DEFAULT_SETTINGS = {
  instituteName: "",
  // Detection tuning
  darkThreshold: 150, // 0-255; a bubble darker than this is plausibly marked
  separationMin: 18, // gap needed vs. runner-up bubble to count as confident
};

function getSettings() {
  try {
    return {
      ...DEFAULT_SETTINGS,
      ...JSON.parse(localStorage.getItem(LS_SETTINGS) || "{}"),
    };
  } catch (e) {
    return { ...DEFAULT_SETTINGS };
  }
}

function saveSettings(patch) {
  const merged = { ...getSettings(), ...patch };
  localStorage.setItem(LS_SETTINGS, JSON.stringify(merged));
  return merged;
}

function getExams() {
  try {
    return JSON.parse(localStorage.getItem(LS_EXAMS) || "[]");
  } catch (e) {
    return [];
  }
}

function saveExams(exams) {
  localStorage.setItem(LS_EXAMS, JSON.stringify(exams));
}

function getExam(id) {
  return getExams().find((e) => e.id === id) || null;
}

function createExam({
  title,
  date,
  numQuestions,
  answerKey,
  sheetFormat = "full",
}) {
  const exams = getExams();
  const exam = {
    id: genId("exam"),
    title,
    date,
    numQuestions,
    answerKey,
    sheetFormat, // "full" (1 sheet per A4) | "compact" (up to 4 sheets per A4)
    createdAt: Date.now(),
    results: [],
  };
  exams.unshift(exam);
  saveExams(exams);
  return exam;
}

function updateExam(id, patch) {
  const exams = getExams();
  const idx = exams.findIndex((e) => e.id === id);
  if (idx === -1) return null;
  exams[idx] = { ...exams[idx], ...patch };
  saveExams(exams);
  return exams[idx];
}

function deleteExam(id) {
  saveExams(getExams().filter((e) => e.id !== id));
}

function addResultToExam(examId, result) {
  const exams = getExams();
  const idx = exams.findIndex((e) => e.id === examId);
  if (idx === -1) return null;
  exams[idx].results.push({
    id: genId("res"),
    scannedAt: Date.now(),
    ...result,
  });
  saveExams(exams);
  return exams[idx];
}

function deleteResultFromExam(examId, resultId) {
  const exams = getExams();
  const exam = exams.find((e) => e.id === examId);
  if (!exam) return null;
  exam.results = exam.results.filter((r) => r.id !== resultId);
  saveExams(exams);
  return exam;
}

function clearAllData() {
  localStorage.removeItem(LS_EXAMS);
  localStorage.removeItem(LS_SETTINGS);
}

/**
 * Generates a unique ID with the given prefix.
 * @param {string} prefix - The prefix for the ID.
 * @returns {string} The generated ID.
 */
function genId(prefix) {
  return (
    prefix +
    "_" +
    Date.now().toString(36) +
    Math.random().toString(36).slice(2, 8)
  );
}

// Globally expose AppStorage for exam.js and scan.js
window.AppStorage = {
  getSettings,
  saveSettings,
  getExams,
  saveExams,
  getExam,
  createExam,
  updateExam,
  deleteExam,
  addResultToExam,
  deleteResultFromExam,
  clearAllData,
  genId,
};
