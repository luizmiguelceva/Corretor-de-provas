# LazyOMR

**Open-source OMR that just works.**

![GitHub license](https://img.shields.io/github/license/Dilshan-H/LazyOMR?style=for-the-badge)
![GitHub last commit](https://img.shields.io/github/last-commit/Dilshan-H/LazyOMR?style=for-the-badge)
![GitHub issues](https://img.shields.io/github/issues/Dilshan-H/LazyOMR?style=for-the-badge)
![GitHub pull requests](https://img.shields.io/github/issues-pr/Dilshan-H/LazyOMR?style=for-the-badge)

<img width="1259" height="619" alt="LazyOMR - Github Banner" src="https://github.com/user-attachments/assets/efc8791e-d888-4acd-b21f-630b8fd91a56" />

LazyOMR lets you create printable MCQ answer sheets, scan them with a phone camera, and score them offline. It is a privacy-first PWA with no backend, and the core app shell is about 280KB and with OpenCV.js, only about 3.4MB.

## What is LazyOMR?

LazyOMR is a lightweight open-source OMR app for teachers, tutors who need a simple way to generate question sheets, scan filled answers, and keep results on the device.

[![VISIT LazyOMR](https://img.shields.io/badge/Visit%20LazyOMR-D6FFD6?style=for-the-badge&logo=data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2NCIgaGVpZ2h0PSI2NCIgZmlsbD0ibm9uZSIgdmlld0JveD0iMCAwIDY0IDY0Ij48cGF0aCBzdHJva2U9ImN1cnJlbnRDb2xvciIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjQiIGQ9Ik0xNCAyNFYxNGgxME01MCAyNFYxNEg0ME0xNCA0MHYxMGgxME01MCA0MHYxMEg0MCIvPjxjaXJjbGUgY3g9IjMyIiBjeT0iMzIiIHI9IjciIHN0cm9rZT0iY3VycmVudENvbG9yIiBzdHJva2Utd2lkdGg9IjQiLz48L3N2Zz4=)](https://lazyomr.vercel.app?utm_source=github)

## Why LazyOMR?

Most OMR tools are either locked behind paid plans, require a server, or focus on scanning only.
Majority of the open-source OMR solutions are either too complex to set up or made for a specific use case.
LazyOMR is built to fill these gaps: it keeps things as simple as possible, generates answer sheets quickly, supports offline scoring, and uses a fully client-side workflow that remains free and open source.

## Features

- Create printable MCQ answer sheets for up to 50 questions, with 5 options (A–E) per question
- Print 1 full-page sheet per A4, or up to 4 compact sheets per A4 page (cut along the dotted lines)
- Scan sheets with the phone camera or upload a photo when needed
- Detect the sheet automatically, then crop, align, and score it on device
- Generate and review exam results entirely offline
- Store exams, settings, and results locally in the browser
- Run as a PWA for a fast mobile-first experience and offline use after installation
- Keep the client footprint small (~280KB/~3.4MB with OpenCV.js)
- No ads, analytics, and backend dependencies

## Inside LazyOMR

<img width="1200" height="686" alt="Screenshots-LazyOMR" src="https://github.com/user-attachments/assets/4b06d163-2994-4c4e-a442-02501a33eaab" />


## How to use LazyOMR?

- Visit [LazyOMR](https://lazyomr.vercel.app?utm_source=github) on your smartphone.
- Install it as a PWA (Progressive Web App) for offline use. (optional)
- Tap `Settings` and add the name of your institution/school.
- Go back to `Home` and tap `New Exam`.
- Fill in the exam details and number of questions, then tap `Next`.
- Enter the answers for all the questions and tap `Next`.
- Review the exam details and tap `Generate printable sheet`.
- Choose the sheet format (`Compact` = up to 4 sheets per A4, `Full page` = 1 per A4) and, for compact sheets, how many sheets to print on the page (1–4).
- Print the sheet/Save as PDF (On the print settings, make sure that scale is 100%, paper size is A4, and `Background graphics` is enabled.)
- Close the print preview and tap `Save Exam`.
- After the students have completed the exam, tap `Start scan` on the home screen.
- Select the exam you want to scan and tap `Scan a sheet`.
- **LazyOMR** will ask for camera access if you haven't granted it already.
- Point the camera at the bubble sheet and make sure that the entire sheet is visible in the camera frame. (For compact sheets, cut the page apart first, or fill the frame with a single sheet — each sheet has its own 4 corner markers.)
- Follow the on-screen instructions to complete the scanning process. **LazyOMR** will automatically detect the sheet and capture the image.
- After scanning, **LazyOMR** will process the image and display the results. You can review the scores and tap `Confirm`.
- Type the name and/or index number of the student and tap `Save result`.
- Tap either `Scan next` or `End of scan` to finish scanning the exam.
- After scanning all the sheets, you will be presented with the overall results. You can view the scores and tap `Export CSV` to download the results as a CSV file.

> [!WARNING]
>
> - Ensure good lighting when scanning bubble sheets for optimal results.
> - Make sure the entire bubble sheet is within the camera frame and clearly visible.
> - Avoid shadows or glare on the bubble sheet that might affect scanning accuracy.
> - Inform students to fill in the bubbles completely and accurately for better recognition.
> - You can adjust the scanning settings in the `Settings` menu to improve accuracy.
> - Smudges, creases, or damage to the bubble sheet may affect scanning accuracy.

## Reading the results

The scanned bubble sheet will have boxes around the detected bubbles. Each color means a different detection result.

<img width="885" height="436" alt="Colors-Legend-LazyOMR" src="https://github.com/user-attachments/assets/aff129a4-e3e4-4164-9e3b-550fc8c079f8" />

## Limitations

- Supports only MCQs with a single correct answer per question.
- Name/Index number fields are entered manually on sheets
- Designed for A4 paper size (210mm x 297mm) and may have issues with other sizes.
- May have difficulty with low-contrast or faded bubbles.
- Image quality and lighting conditions matter.
- Not suitable for high-stakes exams or professional OMR applications.

LazyOMR is designed for small-scale educational use, and it does not handle every edge case. You have to ensure that the bubble sheets are printed clearly, filled in correctly by the students.

## Contributing

You can contribute in many ways:

- Report bugs or suggest improvements
- Improve design, accessibility, or performance

**Got an idea? Found a bug?** Feel free to [open an issue](https://github.com/Dilshan-H/LazyOMR/issues/new) or submit a pull request.

**How to contribute:**

1. Fork the repository
2. Make your changes
3. Submit a pull request

It's that easy! If you're not sure how, check out GitHub's guide: [How to create a pull request in GitHub](https://opensource.com/article/19/7/create-pull-request-github).

## Support the Project

Love LazyOMR? Your support makes a big difference.

<a href="https://www.buymeacoffee.com/dilshanh" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/default-orange.png" alt="Buy Me A Coffee" height="41" width="174"></a>

If you find LazyOMR helpful or want to show your support, please consider starring the repository on GitHub! ⭐

![Static Badge](https://img.shields.io/badge/%E2%AD%90%20Star%20LazyOMR-ecf78c?style=for-the-badge)

It helps others discover the project and motivates continued development :)

## License

**The MIT License**

This program is free software: you can redistribute it and/or modify it under the terms of the MIT License. See the [LICENSE](LICENSE) file for more details. Attribution is required by leaving the author name and license info intact.

## Disclaimer

LazyOMR is provided "as is" without any warranties. The author is not responsible for any issues, damages, or losses that may arise from using this software. Use it at your own risk.
Please ensure that you comply with any applicable laws and regulations when using LazyOMR, especially in educational or professional settings.
It is the user's responsibility to ensure that the results obtained from LazyOMR are accurate and reliable for their intended purpose.
